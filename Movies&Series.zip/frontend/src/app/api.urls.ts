export const apiUrls = {
    authenticationServiceApi: 'http://localhost:8800/api/authentication/'
}